#include<iostream>
using namespace std;
int main(){
    cout<<"Enter Your Age: ";
    int age;
    cin>>age;
if(age>=18){
    cout<<"You are elible to vote."<<endl;
}else{
    cout<<"You are not elibile to vote."<<endl;
}
    return 0;
}
