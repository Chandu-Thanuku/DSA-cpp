A travel agency provide a currency converter tool on their website Tourists can enter the amount in USD to check eqquivalent values in Idian rupees (INR) and Euros (EUR) before planning expenses.
