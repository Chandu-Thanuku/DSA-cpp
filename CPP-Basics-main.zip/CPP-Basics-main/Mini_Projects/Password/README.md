This Program checks that password is strong or Weak.
