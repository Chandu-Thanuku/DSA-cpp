You're creating a weather app that lets users choose between Celcius and Fahrenhit.When a user enters the temperature in Celcius,the app converts it to Fahrenhit for International users.
