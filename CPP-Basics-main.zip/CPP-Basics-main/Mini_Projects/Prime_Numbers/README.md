Our program first takes input n from user then give output prime numbers from 1-n.
