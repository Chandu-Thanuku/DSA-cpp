A Bank building an online tool wheree customers can estimate the interest they'll earn on a simple interest fixed deposit.The use enters the principal,rate of interest and duration in years.
