#include <iostream>
using namespace std;

int main() {
    cout << "For loop: Print numbers 1 to 5" << endl;
    for (int i = 1; i <= 5; i++) {
        cout << i << " ";
    }
    cout << endl;
    return 0;
}
