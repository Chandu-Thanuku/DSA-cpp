#include <iostream>
using namespace std;

int main() {
    int i = 1;
    cout << "While loop: Print numbers 1 to 5" << endl;
    while (i <= 5) {
        cout << i << " ";
        i++;
    }
    cout << endl;
    return 0;
}
