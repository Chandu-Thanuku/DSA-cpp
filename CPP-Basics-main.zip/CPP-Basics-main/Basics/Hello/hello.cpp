#include<iostream>
int main(){
    std::cout<<"hello"<<std::endl;
    std::cout<<"hello";
    return 0;
}
